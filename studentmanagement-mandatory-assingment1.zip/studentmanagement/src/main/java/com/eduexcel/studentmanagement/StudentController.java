/**
 * 
 */
package com.eduexcel.studentmanagement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.eduexcel.studentmanagement.entites.Student;
import com.eduexcel.studentmanagement.services.StudentService;

/**
 * @author Jagadeesht
 *
 */
@RestController
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/students")
	@ResponseBody
	public List<Student> getStudents() {
		return studentService.getStudents();
	}

	@GetMapping("/student/{id}")
	@ResponseBody
	public Student getStudents(@PathVariable("id") Long studentid) {
		return studentService.getStudent(studentid);
	}

	@PostMapping("/student")
	@ResponseBody
	public Student createStudents(@RequestBody Student student) {
		return studentService.createStudent(student);
	}

	@DeleteMapping("/student/{id}")
	@ResponseBody
	public String deleteStudent(@PathVariable("id") Long studentid) {
		return studentService.deleteStudent(studentid);
	}

	@PutMapping("/student")
	@ResponseBody
	public Student updateStudents(@RequestBody Student student) {
		return studentService.updateStudent(student);
	}

}

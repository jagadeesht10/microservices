/**
 * 
 */
package com.eduexcel.studentmanagement.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eduexcel.studentmanagement.entites.Student;
import com.eduexcel.studentmanagement.repository.StudentRepository;

/**
 * @author Jagadeesht
 *
 */
@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	public List<Student> getStudents() {
		return studentRepository.findAll();
	}

	public Student getStudent(Long stundentId) {
		return studentRepository.findById(stundentId).get();
	}

	@Transactional
	public Student createStudent(Student student) {
		return studentRepository.save(student);
	}
	
	@Transactional
	public String deleteStudent(Long stundentId) {
		 studentRepository.deleteById(stundentId);
		 return "deleted Student "+ stundentId;
	}
	
	@Transactional
	public Student updateStudent(Student student) {
		return studentRepository.save(student);
	}
}
